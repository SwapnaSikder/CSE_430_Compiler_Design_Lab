%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node {
    char *name;
    struct node *left;
    struct node *right;
} node;

/* Build AST node */
node* buildTree(char *op, node *left, node *right) {
    node *newnode = (node*)malloc(sizeof(node));
    newnode->name = strdup(op ? op : "");
    newnode->left = left;
    newnode->right = right;
    return newnode;
}

/* Pretty print AST in tree style */
void printTreePretty(node *tree, int indent, int isLast) {
    if (!tree) return;

    for (int i = 0; i < indent - 1; i++) {
        printf("│   ");
    }

    if (indent > 0) {
        printf(isLast ? "└── " : "├── ");
    }

    printf("%s\n", tree->name);

    if (tree->left || tree->right) {
        if (tree->left && tree->right) {
            printTreePretty(tree->left, indent + 1, 0);
            printTreePretty(tree->right, indent + 1, 1);
        } else if (tree->left) {
            printTreePretty(tree->left, indent + 1, 1);
        } else if (tree->right) {
            printTreePretty(tree->right, indent + 1, 1);
        }
    }
}

void yyerror(const char *s) {
    fprintf(stderr, "Error: %s\n", s);
}

int yylex(void);
%}

%union {
    char *sval;
    struct node *ptr;
}

%token <sval> ID NUM STRING
%token INT FLOAT CHAR IF ELSE FOR WHILE
%token LE GE EQ NE LT GT ASSIGN
%token PLUS MINUS MUL DIV MOD
%token MAINTOK INCLUDE COUT ENDL BREAK CONTINUE

%type <ptr> program stmt stmt_list expr cond decl assign for_loop while_loop if_stmt

%%

program:
    stmt_list { printTreePretty($1, 0, 1); }
;

stmt_list:
      stmt                  { $$ = $1; }
    | stmt_list stmt        { $$ = buildTree("stmt_list", $1, $2); }
;

stmt:
      decl ';'              { $$ = $1; }
    | assign ';'            { $$ = $1; }
    | for_loop              { $$ = $1; }
    | while_loop            { $$ = $1; }
    | if_stmt               { $$ = $1; }
;

decl:
      INT ID                { $$ = buildTree("decl_int", buildTree($2, NULL, NULL), NULL); }
    | FLOAT ID              { $$ = buildTree("decl_float", buildTree($2, NULL, NULL), NULL); }
    | CHAR ID               { $$ = buildTree("decl_char", buildTree($2, NULL, NULL), NULL); }
;

assign:
      ID ASSIGN expr        { $$ = buildTree("assign", buildTree($1, NULL, NULL), $3); }
;

expr:
      expr PLUS expr        { $$ = buildTree("+", $1, $3); }
    | expr MINUS expr       { $$ = buildTree("-", $1, $3); }
    | expr MUL expr         { $$ = buildTree("*", $1, $3); }
    | expr DIV expr         { $$ = buildTree("/", $1, $3); }
    | expr MOD expr         { $$ = buildTree("%", $1, $3); }
    | ID                    { $$ = buildTree($1, NULL, NULL); }
    | NUM                   { $$ = buildTree($1, NULL, NULL); }
    | '(' expr ')'          { $$ = $2; }
;

cond:
      expr LT expr          { $$ = buildTree("<", $1, $3); }
    | expr GT expr          { $$ = buildTree(">", $1, $3); }
    | expr LE expr          { $$ = buildTree("<=", $1, $3); }
    | expr GE expr          { $$ = buildTree(">=", $1, $3); }
    | expr EQ expr          { $$ = buildTree("==", $1, $3); }
    | expr NE expr          { $$ = buildTree("!=", $1, $3); }
;

if_stmt:
      IF '(' cond ')' '{' stmt_list '}' 
          { $$ = buildTree("if", $3, $6); }
    | IF '(' cond ')' '{' stmt_list '}' ELSE '{' stmt_list '}' 
          { $$ = buildTree("if_else", buildTree("if", $3, $6), $10); }
;

for_loop:
      FOR '(' assign ';' cond ';' assign ')' '{' stmt_list '}' 
          { 
              $$ = buildTree("for", 
                      buildTree("init", $3, buildTree("cond", $5, $7)), 
                      $10); 
          }
;

while_loop:
      WHILE '(' cond ')' '{' stmt_list '}' 
          { $$ = buildTree("while", $3, $6); }
;

%%

int main() {
    printf("Parsing and building AST...\n");
    yyparse();
    return 0;
}
