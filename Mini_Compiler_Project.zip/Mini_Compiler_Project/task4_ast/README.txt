Task 4: Abstract Syntax Tree (AST)
Tools used: Bison, Flex, GCC
Language: C
Description: Constructs an AST for parsed expressions showing hierarchical structure.

To run:
cd ../task4_ast
bison -d tree.y
flex tree.l
gcc tree.tab.c lex.yy.c -o ast -lfl
./ast < input.c
