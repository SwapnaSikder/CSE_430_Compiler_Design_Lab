Task 2: Symbol Table
Tools used: Flex and GCC
Language: C
Description: Builds a symbol table from source code containing identifiers and their attributes.

To run:
cd ../task2_symbol_table
lex symbol.l
gcc lex.yy.c -o symbol_table
./symbol_table < input.c
