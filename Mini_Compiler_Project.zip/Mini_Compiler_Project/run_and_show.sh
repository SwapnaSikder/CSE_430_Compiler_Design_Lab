#!/usr/bin/env bash
set -e

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTDIR="$ROOT/outputs"
mkdir -p "$OUTDIR"

pause() {
  echo
  read -r -p "Press Enter to continue to next output..."
  echo
}

show_file() {
  local file="$1"
  local title="$2"
  echo "======================================================"
  echo "🔎 $title"
  echo "File: $file"
  echo "------------------------------------------------------"
  if [[ -f "$file" ]]; then
    cat "$file"
  else
    echo "(missing)"
  fi
  echo "======================================================"
  pause
}

# --- TASK 1: Lexer ---
task1() {
  local taskdir="$ROOT/task1_lexer"
  local out="$OUTDIR/task1_lexer_output.txt"
  echo "🔹 Running Task 1 (Lexer)..."
  (cd "$taskdir" && lex token.l && gcc lex.yy.c -o lexer && ./lexer < input.c > "$out") || echo "⚠️ Task1 failed"
  show_file "$out" "Task 1 — Lexer"
}

# --- TASK 2: Symbol Table ---
task2() {
  local taskdir="$ROOT/task2_symbol_table"
  local out="$OUTDIR/task2_symbol_table_output.txt"
  echo "🔹 Running Task 2 (Symbol Table)..."
  (cd "$taskdir" && lex symbol.l && gcc lex.yy.c -o symbol_table && ./symbol_table < input.c > "$out") || echo "⚠️ Task2 failed"
  show_file "$out" "Task 2 — Symbol Table"
}

# --- TASK 3: Syntax Analysis ---
task3() {
  local taskdir="$ROOT/task3_syntax_analysis"
  local out="$OUTDIR/task3_syntax_output.txt"
  echo "🔹 Running Task 3 (Syntax Analysis)..."
  (cd "$taskdir" && bison -d syntax.y && flex syntax.l && gcc syntax.tab.c lex.yy.c -o parser -lfl && ./parser < input.c > "$out") || echo "⚠️ Task3 failed"
  show_file "$out" "Task 3 — Syntax Analysis"
}

# --- TASK 4: AST ---
task4() {
  local taskdir="$ROOT/task4_ast"
  local out="$OUTDIR/task4_ast_output.txt"
  echo "🔹 Running Task 4 (AST)..."
  (cd "$taskdir" && bison -d tree.y && flex tree.l && gcc tree.tab.c lex.yy.c -o ast -lfl && ./ast < input.c > "$out") || echo "⚠️ Task4 failed"
  show_file "$out" "Task 4 — AST"
}

# --- ✅ FIXED TASK 5: Intermediate Code Generation (ICG) ---
task5() {
  local taskdir="$ROOT/task5_icg"
  local out="$OUTDIR/task5_icg_output.txt"
  echo "🔹 Running Task 5 (Intermediate Code Generation — ICG)..."

  # Use tac.y and tac.l (the correct files for ICG)
  if [[ -f "$taskdir/tac.y" && -f "$taskdir/tac.l" ]]; then
    (cd "$taskdir" && bison -d tac.y && flex tac.l && gcc lex.yy.c y.tab.c -lfl -o icg)
    (cd "$taskdir" && ./icg < input.c > "$out") || echo "⚠️ Task5 execution failed"
  else
    echo "⚠️ Missing tac.y or tac.l in $taskdir — cannot build ICG." > "$out"
  fi

  show_file "$out" "Task 5 — Intermediate Code Generation (ICG)"
}

# --- TASK 6: Optimization ---
task6() {
  local taskdir="$ROOT/task6_optimization"
  local out="$OUTDIR/task6_optimization_output.txt"
  echo "🔹 Running Task 6 (Optimization)..."
  if [[ -f "$taskdir/icg_optimize.py" ]]; then
    (cd "$taskdir" && python3 icg_optimize.py input.txt --print > "$out") || echo "⚠️ Task6 failed"
  else
    echo "⚠️ Missing icg_optimize.py in $taskdir" > "$out"
  fi
  show_file "$out" "Task 6 — Optimization"
}

# --- TASK 7: Assembly ---
task7() {
  local taskdir="$ROOT/task7_assembly"
  local out="$OUTDIR/task7_assembly_output.txt"
  echo "🔹 Running Task 7 (Assembly)..."
  if [[ -f "$taskdir/assemble.py" ]]; then
    (cd "$taskdir" && python3 assemble.py input22.txt > "$out") || echo "⚠️ Task7 failed"
  else
    echo "⚠️ Missing assemble.py in $taskdir" > "$out"
  fi
  show_file "$out" "Task 7 — Assembly"
}

# --- RUN ALL TASKS ---
echo "🚀 Starting Mini Compiler full run..."
task1 || true
task2 || true
task3 || true
task4 || true
task5 || true
task6 || true
task7 || true
echo "🎉 All tasks completed. Outputs are saved in: $OUTDIR"


/* cd ~/Documents/Mini_Compiler_Project
chmod +x run_and_show.sh
./run_and_show.sh */
