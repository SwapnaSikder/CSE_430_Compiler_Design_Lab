LDR r0, =a   @ load a
MOV r0, #0
LDR r1, =b   @ load b
MOV r1, #0
MOV r0, #5
MOV r1, #5
MOV r1, #6
LDR r2, =t3   @ load temporary t3
CMP r2, #0
BEQ L0
B L1
L0:
L1:
MOV r0, #0
L2:
LDR r3, =t0   @ load temporary t0
CMP r3, #0
BEQ L3
MOV r0, #6
B L2
L3:
MOV r1, #5
L4:
LDR r4, =t6   @ load temporary t6
CMP r4, #0
BEQ L5
B L4
L5:
