import sys
import re

# -----------------------------
# ARM Assembly Generator Class
# -----------------------------
class ARMGenerator:
    def __init__(self):
        self.var_map = {}       # variable → register
        self.asm_lines = []     # store generated assembly
        self.reg_count = 0      # temporary register counter
        self.loaded_vars = set() # track loaded variables
        self.last_value = {}    # track last constant assigned to avoid redundant MOVs

    # Get a free register
    def get_register(self):
        reg = f"r{self.reg_count}"
        self.reg_count += 1
        return reg

    # Load variable or temporary into register if not already loaded
    def load_var(self, var):
        if var not in self.var_map:
            reg = self.get_register()
            self.var_map[var] = reg
        else:
            reg = self.var_map[var]

        # For normal variables, generate LDR once
        if var not in self.loaded_vars and not var.startswith("t"):
            self.asm_lines.append(f"LDR {reg}, ={var}   @ load {var}")
            self.loaded_vars.add(var)
        # For temporaries, always load when first used
        elif var.startswith("t") and var not in self.loaded_vars:
            self.asm_lines.append(f"LDR {reg}, ={var}   @ load temporary {var}")
            self.loaded_vars.add(var)
        return reg

    # Generate ARM instruction for a single TAC line
    def generate_line(self, line):
        line = line.strip()
        if not line:
            return

        # Label
        if line.endswith(":"):
            self.asm_lines.append(line)
            return

        # Conditional jump: if tX == 0 goto LABEL
        if line.startswith("if"):
            match = re.match(r"if\s+(\w+)\s*==\s*0\s+goto\s+(\w+)", line)
            if match:
                var, label = match.groups()
                reg = self.load_var(var)
                self.asm_lines.append(f"CMP {reg}, #0")
                self.asm_lines.append(f"BEQ {label}")
            return

        # Unconditional jump: goto LABEL
        if line.startswith("goto"):
            label = line.split()[1]
            self.asm_lines.append(f"B {label}")
            return

        # Assignment
        if "=" in line:
            lhs, rhs = [s.strip() for s in line.split("=", 1)]
            reg_lhs = self.load_var(lhs)

            # Constant assignment
            if rhs.isdigit():
                if lhs not in self.last_value or self.last_value[lhs] != int(rhs):
                    self.asm_lines.append(f"MOV {reg_lhs}, #{rhs}")
                    self.last_value[lhs] = int(rhs)
                return

            # Binary operation
            for op in ["+", "-", "*", "/", "%"]:
                if op in rhs:
                    left, right = [s.strip() for s in rhs.split(op)]
                    left_val = f"#{left}" if left.isdigit() else self.load_var(left)
                    right_val = f"#{right}" if right.isdigit() else self.load_var(right)

                    if op == "+":
                        self.asm_lines.append(f"ADD {reg_lhs}, {left_val}, {right_val}")
                    elif op == "-":
                        self.asm_lines.append(f"SUB {reg_lhs}, {left_val}, {right_val}")
                    elif op == "*":
                        self.asm_lines.append(f"MUL {reg_lhs}, {left_val}, {right_val}")
                    elif op == "/":
                        self.asm_lines.append(f"UDIV {reg_lhs}, {left_val}, {right_val}")
                    elif op == "%":
                        tmp = self.get_register()
                        self.asm_lines.append(f"UDIV {tmp}, {left_val}, {right_val}")
                        self.asm_lines.append(f"MUL {tmp}, {tmp}, {right_val}")
                        self.asm_lines.append(f"SUB {reg_lhs}, {left_val}, {tmp}")
                    return

            # Simple variable assignment
            reg_rhs = self.load_var(rhs)
            self.asm_lines.append(f"MOV {reg_lhs}, {reg_rhs}")
            return

    # Generate ARM assembly for all TAC lines
    def generate(self, tac_lines):
        for line in tac_lines:
            self.generate_line(line)
        return self.asm_lines

# -----------------------------
# Main Function
# -----------------------------
def main():
    if len(sys.argv) < 2:
        print("Usage: python assemble.py input22.txt")
        return

    input_file = sys.argv[1]
    output_file = input_file.split('.')[0] + ".s"

    with open(input_file, 'r') as f:
        tac_lines = f.readlines()

    generator = ARMGenerator()
    asm_lines = generator.generate(tac_lines)

    # Save to file & print to terminal simultaneously
    with open(output_file, 'w') as f:
        print("\n--- Optimized ARM Assembly Output ---\n")
        for line in asm_lines:
            f.write(line + '\n')
            print(line)

    print(f"\nAssembly code also saved in {output_file}")

if __name__ == "__main__":
    main()
