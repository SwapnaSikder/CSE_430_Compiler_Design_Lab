Task 7: Assembly Code Generation
Tools used: Python
Language: Python
Description: Converts optimized intermediate code to target assembly language.

To run:
cd ../task7_assembly

python3 assemble.py input22.txt
