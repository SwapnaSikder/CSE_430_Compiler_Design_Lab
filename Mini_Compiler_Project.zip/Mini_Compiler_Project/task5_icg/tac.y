%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int tempCount = 0;
int labelCount = 0;

int yylex();
void yyerror(const char *s);

char* tacLines[1000];
int tacIndex = 0;

char* newTemp() {
    char *t = (char*)malloc(12);
    sprintf(t, "t%d", tempCount++);
    return t;
}

char* newLabel() {
    char *l = (char*)malloc(12);
    sprintf(l, "L%d", labelCount++);
    return l;
}

void emitTAC(const char* line) {
    tacLines[tacIndex++] = strdup(line);
}

void printTAC() {
    printf("=== Three Address Code ===\n");
    for (int i = 0; i < tacIndex; i++)
        printf("%s\n", tacLines[i]);
}

void printQuad() {
    printf("\n=== Quadruple Table ===\n");
    printf("%-10s %-10s %-10s %-10s\n", "Op", "Arg1", "Arg2", "Result");
    printf("----------------------------------------\n");

    for (int i = 0; i < tacIndex; i++) {
        char op[10] = "", arg1[64] = "-", arg2[64] = "-", res[64] = "-";
        char line[128];
        strcpy(line, tacLines[i]);

        // 3-operand expressions
        if (sscanf(line, "%s = %s + %s", res, arg1, arg2) == 3) strcpy(op, "+");
        else if (sscanf(line, "%s = %s - %s", res, arg1, arg2) == 3) strcpy(op, "-");
        else if (sscanf(line, "%s = %s * %s", res, arg1, arg2) == 3) strcpy(op, "*");
        else if (sscanf(line, "%s = %s %% %s", res, arg1, arg2) == 3) strcpy(op, "%%");
        else if (sscanf(line, "%s = %s == %s", res, arg1, arg2) == 3) strcpy(op, "==");
        else if (sscanf(line, "%s = %s < %s", res, arg1, arg2) == 3) strcpy(op, "<");
        else if (sscanf(line, "%s = %s > %s", res, arg1, arg2) == 3) strcpy(op, ">");

        // Simple assignment
        else if (sscanf(line, "%s = %s", res, arg1) == 2) strcpy(op, "=");

        // Condition
        else if (strstr(line, "if") == line) {
            strcpy(op, "if==0");
            sscanf(line, "if %s == 0 goto %s", arg1, res);
        }
        // Goto
        else if (strstr(line, "goto") == line) {
            strcpy(op, "goto");
            sscanf(line, "goto %s", res);
        }
        // Label
        else if (strchr(line, ':')) {
            strcpy(op, "label");
            sscanf(line, "%[^:]:", res);
        } else {
            continue;
        }

        printf("%-10s %-10s %-10s %-10s\n", op, arg1, arg2, res);
    }
}

%}

%union {
    int ival;
    char* str;
}

%token <ival> NUMBER
%token <str> ID
%token SEMICOLON LPAREN RPAREN LBRACE RBRACE
%token ASSIGN PLUS MINUS MOD EQ LT GT
%token INT IF ELSE FOR WHILE

%type <str> expr cond stmt decl
%left PLUS MINUS
%left MOD
%left EQ LT GT

%%

program:
    decls stmts { 
        printTAC();
        printQuad();
    }
;

decls:
      /* empty */
    | decls decl
;

decl:
    INT ID SEMICOLON {
        char line[50];
        sprintf(line, "%s = 0", $2);
        emitTAC(line);
    }
;

stmts:
      /* empty */
    | stmts stmt
;

stmt:
    ID ASSIGN expr SEMICOLON {
        char line[50];
        sprintf(line, "%s = %s", $1, $3);
        emitTAC(line);
    }
    | IF LPAREN cond RPAREN LBRACE stmts RBRACE ELSE LBRACE stmts RBRACE {
        char *Lelse = newLabel();
        char *Lend  = newLabel();
        char line[50];

        sprintf(line, "if %s == 0 goto %s", $3, Lelse);
        emitTAC(line);
        sprintf(line, "goto %s", Lend);
        emitTAC(line);
        sprintf(line, "%s:", Lelse);
        emitTAC(line);
        sprintf(line, "%s:", Lend);
        emitTAC(line);
    }
    | WHILE LPAREN cond RPAREN LBRACE stmts RBRACE {
        char *Lstart = newLabel();
        char *Lend   = newLabel();
        char line[50];

        sprintf(line, "%s:", Lstart);
        emitTAC(line);
        sprintf(line, "if %s == 0 goto %s", $3, Lend);
        emitTAC(line);
        sprintf(line, "goto %s", Lstart);
        emitTAC(line);
        sprintf(line, "%s:", Lend);
        emitTAC(line);
    }
    | FOR LPAREN ID ASSIGN expr SEMICOLON cond SEMICOLON ID ASSIGN expr RPAREN LBRACE stmts RBRACE {
        char *Lstart = newLabel();
        char *Lend   = newLabel();
        char line[50];

        sprintf(line, "%s = %s", $3, $5);
        emitTAC(line);
        sprintf(line, "%s:", Lstart);
        emitTAC(line);
        sprintf(line, "if %s == 0 goto %s", $7, Lend);
        emitTAC(line);
        sprintf(line, "%s = %s", $9, $11);
        emitTAC(line);
        sprintf(line, "goto %s", Lstart);
        emitTAC(line);
        sprintf(line, "%s:", Lend);
        emitTAC(line);
    }
;

expr:
      NUMBER {
          $$ = (char*)malloc(12);
          sprintf($$, "%d", $1);
      }
    | ID { $$ = $1; }
    | expr PLUS expr {
          char *t = newTemp();
          char line[50];
          sprintf(line, "%s = %s + %s", t, $1, $3);
          emitTAC(line);
          $$ = t;
      }
    | expr MINUS expr {
          char *t = newTemp();
          char line[50];
          sprintf(line, "%s = %s - %s", t, $1, $3);
          emitTAC(line);
          $$ = t;
      }
    | expr MOD expr {
          char *t = newTemp();
          char line[50];
          sprintf(line, "%s = %s %% %s", t, $1, $3);
          emitTAC(line);
          $$ = t;
      }
;

cond:
      expr EQ expr {
          char *t = newTemp();
          char line[50];
          sprintf(line, "%s = %s == %s", t, $1, $3);
          emitTAC(line);
          $$ = t;
      }
    | expr LT expr {
          char *t = newTemp();
          char line[50];
          sprintf(line, "%s = %s < %s", t, $1, $3);
          emitTAC(line);
          $$ = t;
      }
    | expr GT expr {
          char *t = newTemp();
          char line[50];
          sprintf(line, "%s = %s > %s", t, $1, $3);
          emitTAC(line);
          $$ = t;
      }
;

%%

int main() {
    yyparse();
    return 0;
}

void yyerror(const char *s) {
    fprintf(stderr, "Parse error: %s\n", s);
}
