Task 5: Intermediate Code Generation (ICG)
Tools used: Bison, Flex, GCC
Language: C
Description: Generates three-address code (TAC) from AST.

To run:
cd ../task5_icg
lex tac.l
yacc -d tac.y
gcc lex.yy.c y.tab.c -lfl -o tac
./tac < input.c
