%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex();
void yyerror(const char *s);

struct symbol {
    char name[100];
    char dtype[20];
    int scope;
    int value;
};

struct symbol symtab[100];
int symcount = 0;

void add_symbol(char *name, char *dtype, int scope, int value) {
    strcpy(symtab[symcount].name, name);
    strcpy(symtab[symcount].dtype, dtype);
    symtab[symcount].scope = scope;
    symtab[symcount].value = value;
    symcount++;
}
%}

%union {
    char *str;
}

%token <str> ID NUMBER
%token INT IF ELSE WHILE FOR
%token EQ GT LT PLUS MINUS MOD ASSIGN SEMICOLON LPAREN RPAREN LBRACE RBRACE

%type <str> expr

%start program

%%
program:
    | program stmt
    ;

stmt:
      decl
    | assignment SEMICOLON
    | for_stmt
    | while_stmt
    | if_stmt
    | LBRACE program RBRACE
    ;

decl:
    INT ID SEMICOLON
    {
        add_symbol($2, "int", 1, 0);
    }
    ;

assignment:
    ID ASSIGN expr
    ;

expr:
    NUMBER        { $$ = $1; }
    | ID          { $$ = $1; }
    | expr PLUS expr  { $$ = $1; }  /* Simplified for demonstration */
    | expr MINUS expr { $$ = $1; }
    | expr MOD expr   { $$ = $1; }
    | expr EQ expr    { $$ = $1; }
    | expr LT expr    { $$ = $1; }
    | expr GT expr    { $$ = $1; }
    ;

for_stmt:
    FOR LPAREN assignment SEMICOLON expr SEMICOLON assignment RPAREN stmt
    ;

while_stmt:
    WHILE LPAREN expr RPAREN stmt
    ;

if_stmt:
    IF LPAREN expr RPAREN stmt
    | IF LPAREN expr RPAREN stmt ELSE stmt
    ;
%%

void yyerror(const char *s) {
    fprintf(stderr, "parse error: %s\n", s);
}

int main() {
    yyparse();

    printf("\nSymbol Table\n");
    printf("Symbol\tScope\tdtype\tValue\n");
    for (int i = 0; i < symcount; i++) {
        printf("%s\t%d\t%s\t%d\n", symtab[i].name, symtab[i].scope, symtab[i].dtype, symtab[i].value);
    }
    return 0;
}