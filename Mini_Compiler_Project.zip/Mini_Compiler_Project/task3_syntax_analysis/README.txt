Task 3: Syntax Analysis
Tools used: Bison (Yacc), Flex, GCC
Language: C
Description: Parses the input tokens according to grammar rules and detects syntax errors.

To run:
cd ../task3_syntax_analysis
bison -d syntax.y
flex syntax.l
gcc syntax.tab.c lex.yy.c -o parser -lfl
./parser < input.c
