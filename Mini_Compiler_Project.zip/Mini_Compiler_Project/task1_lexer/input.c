int a;
int b;
a = 5;
b = 0;
for (a = 0; a < 5; a = a + 1) {
    if (a % 2 == 0) {
        b = b + a;
    } else {
        b = b + 1;
    }
}
while (b > 0) {
    b = b - 1;
}
