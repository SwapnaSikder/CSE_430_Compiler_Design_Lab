Task 1: Lexical Analysis
Tools used: Flex (Lex) and GCC
Language: C
Description: Tokenizes the input source code into identifiers, keywords, operators, etc.

To run:
cd task1_lexer
lex token.l
gcc lex.yy.c -o lexer
./lexer < input.c
