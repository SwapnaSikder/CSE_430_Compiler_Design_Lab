import sys
import re

# -----------------------------
# Constant Folding
# -----------------------------
def constant_folding(line: str) -> str:
    """
    Simplify arithmetic expressions like:
    t1 = 2 + 3  →  t1 = 5
    """
    pattern = r"(\w+)\s*=\s*(\d+)\s*([\+\-\*/%])\s*(\d+)"
    match = re.match(pattern, line)
    if match:
        var, a, op, b = match.groups()
        a, b = int(a), int(b)
        try:
            result = {
                '+': a + b,
                '-': a - b,
                '*': a * b,
                '/': a // b if b != 0 else a,
                '%': a % b
            }[op]
            return f"{var} = {result}"
        except Exception:
            return line
    return line

# -----------------------------
# Constant Propagation
# -----------------------------
def constant_propagation(lines):
    const_map = {}  # variable -> constant
    new_lines = []

    for line in lines:
        if '=' not in line or line.strip().startswith("if"):
            new_lines.append(line)
            continue

        lhs, rhs = [s.strip() for s in line.split('=', 1)]

        # Replace known constants in RHS
        for var, val in const_map.items():
            rhs = re.sub(rf"\b{var}\b", str(val), rhs)

        # Apply constant folding
        new_line = constant_folding(f"{lhs} = {rhs}")

        # Track constants
        match = re.match(r"(\w+)\s*=\s*(\d+)$", new_line)
        if match:
            const_map[match.group(1)] = match.group(2)
        else:
            const_map.pop(lhs, None)

        new_lines.append(new_line)

    return new_lines

# -----------------------------
# Dead Code Elimination
# -----------------------------
def dead_code_elimination(lines):
    used = set()
    for line in lines:
        if '=' in line and not line.strip().startswith("if"):
            rhs = line.split('=')[1]
            vars_rhs = re.findall(r"\b[a-zA-Z_]\w*\b", rhs)
            used.update(vars_rhs)

    optimized = []
    for line in lines:
        if '=' in line and not line.strip().startswith("if"):
            lhs = line.split('=')[0].strip()
            if lhs.startswith('t') and lhs not in used:
                continue
        optimized.append(line)

    return optimized

# -----------------------------
# Fix spacing for if-statements
# -----------------------------
def fix_if_format(lines):
    """
    Ensure all 'if' statements use '==' properly with no extra spaces.
    """
    new_lines = []
    for line in lines:
        if line.strip().startswith("if"):
            # Remove extra spaces around ==
            line = re.sub(r"=\s*=", "==", line)
        new_lines.append(line)
    return new_lines

# -----------------------------
# Full Optimization Pass
# -----------------------------
def optimize_icg(lines):
    lines = [ln.strip() for ln in lines if ln.strip()]
    lines = constant_propagation(lines)
    lines = [constant_folding(line) for line in lines]
    lines = dead_code_elimination(lines)
    lines = fix_if_format(lines)
    return lines

# -----------------------------
# Main
# -----------------------------
def main():
    if len(sys.argv) < 2:
        print("Usage: python3 icg_optimize.py input.txt [--print]")
        return

    input_file = sys.argv[1]
    print_flag = "--print" in sys.argv
    output_file = "optimized.txt"

    with open(input_file, 'r') as f:
        lines = f.readlines()

    optimized = optimize_icg(lines)

    with open(output_file, 'w') as f:
        for line in optimized:
            f.write(line + '\n')

    if print_flag:
        print("\n--- Optimized TAC ---")
        for line in optimized:
            print(line)


if __name__ == "__main__":
    main()
