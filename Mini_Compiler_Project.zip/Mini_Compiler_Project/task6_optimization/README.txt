Task 6: Code Optimization
Tools used: Python
Language: Python
Description: Optimizes three-address code by removing redundancies and simplifying expressions.

To run:
cd ../task6_optimization
python3 icg_optimize.py input.txt --print

